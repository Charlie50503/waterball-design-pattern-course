import { Hand } from './hand';

export abstract class Player<CardType> {
  name: string = '';
  hand: Hand<CardType>;
  playedCard!: CardType | null;

  constructor(hand: Hand<CardType>) {
    this.hand = hand;
  }
  nameHimself(name: string) {
    this.name = name;
  }

  abstract play(): Promise<CardType>;

  setCard(card: CardType | null) {
    this.playedCard = card;
  }

  getPlayedCard() {
    return this.playedCard;
  }
}
