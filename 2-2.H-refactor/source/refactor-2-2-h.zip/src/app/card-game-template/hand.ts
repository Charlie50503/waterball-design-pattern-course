export class Hand<CardType> {
  cards:CardType[] = [];

  appendCard(card: CardType) {
    this.cards.push(card);
  }
}