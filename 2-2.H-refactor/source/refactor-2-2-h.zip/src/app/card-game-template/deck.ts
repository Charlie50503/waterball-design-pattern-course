export abstract class Deck<CardType> {
  cards: CardType[] = [];

  constructor() {
    this.initDeck();
  }
  //  初始化牌組,建立牌組卡牌數量
  public abstract initDeck(): void;

  public shuffle() {
    let m = this.cards.length,
      t,
      i;
    // 如果還剩有元素未洗牌
    while (m) {
      // 選取剩餘元素…
      i = Math.floor(Math.random() * m--);
      // 並與當前元素進行交換
      t = this.cards[m];
      this.cards[m] = this.cards[i];
      this.cards[i] = t;
    }
  }

  public drawCard() {
    if (this.cards.length === 0) {
      throw Error('Deck is empty');
    }
    return this.cards.splice(this.cards.length - 1, 1)[0];
  }
}
