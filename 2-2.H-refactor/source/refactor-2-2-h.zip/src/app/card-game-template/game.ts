import { Deck } from './deck';
import { Player } from './player';

export type PlayerNames = {
  [key: string]: string;
  player1Name: string;
  player2Name: string;
  player3Name: string;
  player4Name: string;
};

export abstract class Game<CardType> {
  deck!: Deck<CardType>;
  players: Player<CardType>[] = [];
  round: number = 0;

  constructor(
    player1: Player<CardType>,
    player2: Player<CardType>,
    player3: Player<CardType>,
    player4: Player<CardType>
  ) {
    this.players = [player1, player2, player3, player4];
  }
  // 遊戲初始化
  initGame(playerNames: PlayerNames, deck: Deck<CardType>): void {
    const gameInit = new GameInit<CardType>(this.getInitialHandSize());
    gameInit.namePlayers(this.players, playerNames);
    this.deck = gameInit.shuffleDeck(deck);
    gameInit.initialHandDrawCard(this.deck, this.players);
  }
  // 遊戲開始前 hook
  abstract beforeGameStart(): void;
  // 遊戲開始
  async startGame(): Promise<void> {
    this.beforeGameStart();
    while(this.isGameOver()){
      this.players.forEach((player) => {
        this.eachPlayerAction(this,player)
      })
      this.onRoundEnd();
      this.round++;
    }
    this.onGameEnd();
  }
  async handlePlayCard(player: Player<CardType>): Promise<CardType> {
    const card = await player.play();
    if (!this.isValidPlayed(card)) {
      return this.handlePlayCard(player);
    } else {
      return card;
    }
  }
  // 出牌可不可以被看到
  abstract isVisibleShowedCard(): boolean;
  // 確認是否達成遊戲結束條件
  abstract isGameOver(): boolean;
  abstract getInitialHandSize(): number;

  abstract getWinner(): Player<CardType>;

  abstract eachPlayerAction(game:Game<CardType>, player:Player<CardType>): void;
  abstract onRoundEnd(): void;
  abstract onPlayerEndOfRound(player: Player<CardType>, card: CardType): void;
  abstract isValidPlayed(card: CardType): boolean;

  private onGameEnd(){
    const winner = this.getWinner()
    console.log(`贏家是` + winner.name);
  }
}

class GameInit<CardType> {
  constructor(private initialHandSize: number) {}
  // 1. P1~P4 (Name himself)。
  public namePlayers(players: Player<CardType>[], playerNames: PlayerNames) {
    let playerNameKeys = Object.keys(playerNames);
    for (let i = 0; i < playerNameKeys.length; i++) {
      players[i].nameHimself(playerNames[playerNameKeys[i]]);
    }
  }
  // 2. 初始化 牌組 Deck ，
  // 3. Deck (Shuffle)。
  public shuffleDeck(deck: Deck<CardType>) {
    deck.shuffle();
    return deck;
  }
  // 4. 由 P1 開始，P1~P4 輪流 (Draw Card) 直到所設定的 "抽牌終止條件" 出現為止
  public initialHandDrawCard(
    deck: Deck<CardType>,
    players: Player<CardType>[]
  ) {
    let count = 0;
    while (this.isInitialHandDrawCardEnd(count)) {
      const card = deck.drawCard();
      players.forEach((player) => player.hand.appendCard(card));
      count++;
    }
  }
  // 抽牌終止條件
  private isInitialHandDrawCardEnd(times: number) {
    return this.initialHandSize > times;
  }
}
