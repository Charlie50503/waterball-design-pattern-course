import { Game } from '../card-game-template/game';
import { Player } from '../card-game-template/player';
import { UnoCard } from './unoCard';
import { UnoPlayer } from './unoPlayer';

export class UnoGame extends Game<UnoCard> {
  topCard!: UnoCard;
  beforeGameStart(): void {
    this.topCard = this.deck.drawCard();
  }

  getInitialHandSize(): number {
    return 5;
  }

  getWinner(): Player<UnoCard> {
    return this.players.filter((player) => player.hand.cards.length === 0)[0];
  }

  isGameOver(): boolean {
    return (
      this.players.filter((player) => player.hand.cards.length === 0).length > 0
    );
  }

  isVisibleShowedCard(): boolean {
    return true;
  }

  onRoundEnd(): void {
    return;
  }
  onPlayerEndOfRound(player: UnoPlayer, card: UnoCard): void {
    this.topCard = card;
  }

  isValidPlayed(card: UnoCard): boolean {
    return (
      this.topCard.color === card.color || this.topCard.number === card.number
    );
  }
}
