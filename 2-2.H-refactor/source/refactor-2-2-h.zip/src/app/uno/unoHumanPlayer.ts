import rl from '../helper/readline';
import { UnoCard } from './unoCard';
import { UnoPlayer } from './unoPlayer';

export class UnoHumanPlayer extends UnoPlayer {
  async showCard(): Promise<UnoCard> {
    this.viewCards();
    return await this.handleCommandLineSelectCard();
  }

  viewCards() {
    this.hand.cards.forEach((card, index) => {
      console.log(`編號:${index} 卡牌 花色 ${card.color} ,數字${card.number}`);
    });
  }
  async handleCommandLineSelectCard(): Promise<UnoCard> {
    try {
      const card = await this.commandLineSelectCard();
      return card;
    } catch (error) {
      console.log(error);
      // 再次處理，直到成功或用戶選擇停止
      return this.handleCommandLineSelectCard();
    }
  }

  commandLineSelectCard(): Promise<UnoCard> {
    return new Promise((resolve, reject) => {
      rl.question(`請輸入編號選擇卡牌：`, (index) => {
        if (isNaN(Number(index))) {
          return reject('請輸入數字');
        } else if (Number(index) > this.hand.cards.length - 1) {
          return reject('無效編號');
        }
        return resolve(this.hand.cards[Number(index)]);
      });
    });
  }
}
