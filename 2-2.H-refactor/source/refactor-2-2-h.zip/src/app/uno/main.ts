import { Hand } from '../card-game-template/hand';
import { UnoDeck } from './deck';
import { UnoAIPlayer } from './unoAiPlayer';
import { UnoGame } from './unoGame';
import { UnoHumanPlayer } from './unoHumanPlayer';

export function unoMain() {
  const unoGame = new UnoGame(
    new UnoAIPlayer(new Hand()),
    new UnoAIPlayer(new Hand()),
    new UnoHumanPlayer(new Hand()),
    new UnoAIPlayer(new Hand())
  );
  unoGame.initGame({
    player1Name:"AI1",
    player2Name:"AI2",
    player3Name:"Human3",
    player4Name:"AI4",
  },new UnoDeck());
  unoGame.beforeGameStart();
  unoGame.startGame();
}
