import { Player } from '../card-game-template/player';
import { UnoCard } from './unoCard';

export abstract class UnoPlayer extends Player<UnoCard> {
  async play():Promise<UnoCard> {
    const card = await this.showCard();
    this.setCard(card);
    return Promise.resolve(card);
  }
  abstract showCard(): Promise<UnoCard>;
}
