import { Deck } from '../card-game-template/deck';
import { Color, UnoCard, UnoNumber } from './unoCard';

export class UnoDeck extends Deck<UnoCard> {
  playedCards: UnoCard[] = [];

  public initDeck(): void {
    const colors: Color[] = ['BLUE', 'RED', 'YELLOW', 'GREEN'];
    const numbers: UnoNumber[] = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
    colors.forEach((color) => {
      numbers.forEach((number) => {
        this.cards.push(new UnoCard(color, number));
      });
    });
    console.log(this.cards);
  }

  appendPlayedCard(card: UnoCard): void {
    this.playedCards.push(card);
  }
}
