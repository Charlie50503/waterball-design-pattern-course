import { UnoCard } from './unoCard';
import { UnoPlayer } from './unoPlayer';

export class UnoAIPlayer extends UnoPlayer {
  showCard(): Promise<UnoCard> {
    if (this.hand.cards.length === 0) {
      throw new Error('Hand is empty.');
    }
    const randomIndex = Math.floor(Math.random() * this.hand.cards.length);
    const selectedCard = this.hand.cards[randomIndex];
    return Promise.resolve(selectedCard);
  }
}
