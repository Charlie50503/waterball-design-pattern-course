import { unoMain } from "./app/uno/main";

function main(){
  unoMain();
}

main();